import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, UserPlus, MessageCircle } from "lucide-react";

export default function RecentActivity() {
  // This component shows recent activity items
  // In a real application, this would fetch data from an API
  // For now, we'll show a placeholder structure that matches the design
  
  const activities = [
    {
      id: 1,
      type: "resolved",
      icon: CheckCircle,
      iconBg: "bg-success/10",
      iconColor: "text-success",
      title: "Ticket #T-2024-001 resolved",
      time: "2 minutes ago"
    },
    {
      id: 2,
      type: "assigned",
      icon: UserPlus,
      iconBg: "bg-primary/10", 
      iconColor: "text-primary",
      title: "New ticket assigned to you",
      time: "15 minutes ago"
    },
    {
      id: 3,
      type: "comment",
      icon: MessageCircle,
      iconBg: "bg-warning/10",
      iconColor: "text-warning",
      title: "Comment added to #T-2024-003",
      time: "1 hour ago"
    }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start space-x-3">
            <div className={`w-8 h-8 ${activity.iconBg} rounded-full flex items-center justify-center flex-shrink-0`}>
              <activity.icon className={`${activity.iconColor} text-xs`} size={12} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-gray-900">{activity.title}</p>
              <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
