import { Card, CardContent } from "@/components/ui/card";
import { 
  AlertCircle, 
  Clock, 
  CheckCircle, 
  Timer 
} from "lucide-react";

interface StatsCardsProps {
  stats?: any;
  isLoading: boolean;
}

export default function StatsCards({ stats, isLoading }: StatsCardsProps) {
  const statsData = [
    {
      title: "Open Tickets",
      value: stats?.openTickets ?? 0,
      icon: AlertCircle,
      bgColor: "bg-warning/10",
      iconColor: "text-warning",
      change: "+12%",
      changeType: "increase" as const,
      changeDescription: "from last week",
    },
    {
      title: "In Progress",
      value: stats?.inProgressTickets ?? 0,
      icon: Clock,
      bgColor: "bg-primary/10",
      iconColor: "text-primary",
      change: "-5%",
      changeType: "decrease" as const,
      changeDescription: "from last week",
    },
    {
      title: "Resolved Today",
      value: stats?.resolvedToday ?? 0,
      icon: CheckCircle,
      bgColor: "bg-success/10",
      iconColor: "text-success",
      change: "+18%",
      changeType: "increase" as const,
      changeDescription: "from yesterday",
    },
    {
      title: "Avg. Response",
      value: stats?.avgResponseTime ?? "2.4h",
      icon: Timer,
      bgColor: "bg-secondary/10",
      iconColor: "text-secondary",
      change: "-0.3h",
      changeType: "decrease" as const,
      changeDescription: "improvement",
    },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="animate-pulse">
                <div className="flex items-center justify-between mb-4">
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                </div>
                <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
                <div className="h-4 bg-gray-200 rounded w-2/3"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statsData.map((stat, index) => (
        <Card key={index}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">{stat.title}</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">{stat.value}</p>
              </div>
              <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                <stat.icon className={`${stat.iconColor} text-xl`} size={20} />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span 
                className={`font-medium ${
                  stat.changeType === "increase" 
                    ? stat.title === "Open Tickets" 
                      ? "text-red-600" 
                      : "text-green-600"
                    : "text-green-600"
                }`}
              >
                {stat.change}
              </span>
              <span className="text-gray-500 ml-2">{stat.changeDescription}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
