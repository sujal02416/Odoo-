import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/topbar";
import TicketCard from "@/components/tickets/ticket-card";
import CreateTicketModal from "@/components/tickets/create-ticket-modal";
import TicketDetailModal from "@/components/tickets/ticket-detail-modal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Tickets() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [filters, setFilters] = useState({
    status: "",
    categoryId: "",
    sortBy: "created",
    sortOrder: "desc",
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: ticketsData, isLoading: ticketsLoading } = useQuery({
    queryKey: ["/api/tickets", filters],
    retry: false,
  });

  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
    retry: false,
  });

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "open": return "destructive";
      case "in_progress": return "default";
      case "resolved": return "secondary";
      case "closed": return "outline";
      default: return "default";
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        <TopBar 
          title="All Tickets"
          subtitle="Manage and track all support tickets"
          onCreateTicket={() => setCreateModalOpen(true)}
        />

        <div className="flex-1 overflow-y-auto p-6">
          {/* Filters */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-900">Filters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                <Select 
                  value={filters.status}
                  onValueChange={(value) => setFilters(prev => ({ ...prev, status: value }))}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="All Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Status</SelectItem>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>

                <Select 
                  value={filters.categoryId}
                  onValueChange={(value) => setFilters(prev => ({ ...prev, categoryId: value }))}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Categories</SelectItem>
                    {categories?.map((category: any) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select 
                  value={filters.sortBy}
                  onValueChange={(value) => setFilters(prev => ({ ...prev, sortBy: value }))}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="created">Created Date</SelectItem>
                    <SelectItem value="updated">Last Updated</SelectItem>
                    <SelectItem value="priority">Priority</SelectItem>
                    <SelectItem value="replies">Most Replied</SelectItem>
                  </SelectContent>
                </Select>

                <Button 
                  variant="outline"
                  onClick={() => setFilters({ status: "", categoryId: "", sortBy: "created", sortOrder: "desc" })}
                >
                  Clear Filters
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Tickets List */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-semibold text-gray-900">
                  Tickets {ticketsData?.total && `(${ticketsData.total})`}
                </CardTitle>
                <div className="flex items-center space-x-2">
                  {filters.status && (
                    <Badge variant={getStatusBadgeVariant(filters.status)}>
                      {filters.status.replace('_', ' ').toUpperCase()}
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {ticketsLoading ? (
                <div className="p-6">
                  <div className="animate-pulse space-y-4">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="h-20 bg-gray-200 rounded"></div>
                    ))}
                  </div>
                </div>
              ) : ticketsData?.tickets?.length === 0 ? (
                <div className="p-6 text-center">
                  <p className="text-gray-500">No tickets found matching your criteria.</p>
                  <Button 
                    className="mt-4"
                    onClick={() => setCreateModalOpen(true)}
                  >
                    Create First Ticket
                  </Button>
                </div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {ticketsData?.tickets?.map((ticket: any) => (
                    <TicketCard 
                      key={ticket.id} 
                      ticket={ticket} 
                      onClick={() => setSelectedTicketId(ticket.id)}
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Modals */}
      <CreateTicketModal 
        open={createModalOpen}
        onOpenChange={setCreateModalOpen}
      />
      
      {selectedTicketId && (
        <TicketDetailModal 
          ticketId={selectedTicketId}
          open={!!selectedTicketId}
          onOpenChange={() => setSelectedTicketId(null)}
        />
      )}
    </div>
  );
}
