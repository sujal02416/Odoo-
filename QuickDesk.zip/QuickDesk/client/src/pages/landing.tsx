import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Headset, TicketIcon, Users, TrendingUp } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Headset className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-semibold text-gray-900">QuickDesk</span>
            </div>
            <Button 
              onClick={() => window.location.href = "/api/login"}
              className="bg-primary hover:bg-primary/90"
            >
              Sign In
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 sm:text-6xl">
            Streamlined Help Desk
            <br />
            <span className="text-primary">Support System</span>
          </h1>
          <p className="mt-6 text-xl text-gray-600 max-w-3xl mx-auto">
            Efficient ticket management, seamless communication between users and support teams, 
            with role-based access control and real-time notifications.
          </p>
          <div className="mt-10">
            <Button 
              size="lg"
              onClick={() => window.location.href = "/api/login"}
              className="bg-primary hover:bg-primary/90 px-8 py-3 text-lg"
            >
              Get Started
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <TicketIcon className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Smart Ticket Management</CardTitle>
              <CardDescription>
                Create, track, and manage support tickets with categories, priorities, and status updates.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Role-Based Access</CardTitle>
              <CardDescription>
                Secure access control for end users, support agents, and administrators with appropriate permissions.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Real-time Notifications</CardTitle>
              <CardDescription>
                Email alerts for ticket creation, status changes, and comments to keep everyone informed.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* CTA Section */}
        <div className="mt-20 bg-primary rounded-2xl p-8 text-center">
          <h2 className="text-3xl font-bold text-primary-foreground mb-4">
            Ready to improve your support workflow?
          </h2>
          <p className="text-primary-foreground/90 mb-6 text-lg">
            Join teams who trust QuickDesk to handle their customer support efficiently.
          </p>
          <Button 
            size="lg"
            variant="secondary"
            onClick={() => window.location.href = "/api/login"}
            className="px-8 py-3 text-lg"
          >
            Sign In to Get Started
          </Button>
        </div>
      </div>
    </div>
  );
}
