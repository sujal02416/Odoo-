import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { sendNotificationEmail } from "./email";
import {
  insertTicketSchema,
  insertCommentSchema,
  insertCategorySchema,
  insertTicketVoteSchema,
} from "@shared/schema";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  dest: uploadDir,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "application/pdf", "text/plain"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type"));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard stats
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const stats = await storage.getDashboardStats(userId, user?.role);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Categories
  app.get('/api/categories', isAuthenticated, async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.post('/api/categories', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Only admins can create categories" });
      }

      const validatedData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(validatedData);
      res.json(category);
    } catch (error) {
      console.error("Error creating category:", error);
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  // Tickets
  app.get('/api/tickets', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const filters = {
        status: req.query.status as string,
        categoryId: req.query.categoryId as string,
        assignedToId: req.query.assignedToId === "me" ? userId : req.query.assignedToId as string,
        createdById: req.query.createdById === "me" ? userId : req.query.createdById as string,
        search: req.query.search as string,
        sortBy: req.query.sortBy as "created" | "updated" | "priority" | "replies",
        sortOrder: req.query.sortOrder as "asc" | "desc",
        limit: req.query.limit ? parseInt(req.query.limit as string) : undefined,
        offset: req.query.offset ? parseInt(req.query.offset as string) : undefined,
      };

      // Remove undefined values
      Object.keys(filters).forEach(key => {
        if (filters[key as keyof typeof filters] === undefined) {
          delete filters[key as keyof typeof filters];
        }
      });

      const result = await storage.getTickets(filters);
      res.json(result);
    } catch (error) {
      console.error("Error fetching tickets:", error);
      res.status(500).json({ message: "Failed to fetch tickets" });
    }
  });

  app.get('/api/tickets/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const ticket = await storage.getTicket(req.params.id, userId);
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      res.json(ticket);
    } catch (error) {
      console.error("Error fetching ticket:", error);
      res.status(500).json({ message: "Failed to fetch ticket" });
    }
  });

  app.post('/api/tickets', isAuthenticated, upload.array('attachments', 5), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertTicketSchema.parse({
        ...req.body,
        createdById: userId,
      });

      const ticket = await storage.createTicket(validatedData);

      // Handle file attachments
      if (req.files && req.files.length > 0) {
        for (const file of req.files) {
          await storage.addAttachment({
            ticketId: ticket.id,
            filename: file.filename,
            originalName: file.originalname,
            mimeType: file.mimetype,
            size: file.size,
            uploadedById: userId,
          });
        }
      }

      // Send notification email to agents
      try {
        await sendNotificationEmail("ticket_created", {
          ticketId: ticket.id,
          subject: ticket.subject,
          createdBy: req.user.claims.email || "Unknown User",
        });
      } catch (emailError) {
        console.error("Failed to send notification email:", emailError);
      }

      const ticketWithDetails = await storage.getTicket(ticket.id, userId);
      res.json(ticketWithDetails);
    } catch (error) {
      console.error("Error creating ticket:", error);
      res.status(500).json({ message: "Failed to create ticket" });
    }
  });

  app.put('/api/tickets/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const { status } = req.body;

      if (!["open", "in_progress", "resolved", "closed"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }

      // Only agents and admins can change status
      if (user?.role !== "agent" && user?.role !== "admin") {
        return res.status(403).json({ message: "Only agents can update ticket status" });
      }

      const ticket = await storage.updateTicket(req.params.id, { status });
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      // Send notification email to ticket creator
      const ticketDetails = await storage.getTicket(req.params.id);
      if (ticketDetails) {
        try {
          await sendNotificationEmail("status_updated", {
            ticketId: ticket.id,
            subject: ticketDetails.subject,
            status: status,
            recipientEmail: ticketDetails.createdBy.email,
          });
        } catch (emailError) {
          console.error("Failed to send notification email:", emailError);
        }
      }

      res.json(ticket);
    } catch (error) {
      console.error("Error updating ticket status:", error);
      res.status(500).json({ message: "Failed to update ticket status" });
    }
  });

  app.put('/api/tickets/:id/assign', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const { assignedToId } = req.body;

      // Only agents and admins can assign tickets
      if (user?.role !== "agent" && user?.role !== "admin") {
        return res.status(403).json({ message: "Only agents can assign tickets" });
      }

      const ticket = await storage.assignTicket(req.params.id, assignedToId || userId);
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      res.json(ticket);
    } catch (error) {
      console.error("Error assigning ticket:", error);
      res.status(500).json({ message: "Failed to assign ticket" });
    }
  });

  // Comments
  app.post('/api/tickets/:id/comments', isAuthenticated, upload.array('attachments', 5), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertCommentSchema.parse({
        ticketId: req.params.id,
        authorId: userId,
        content: req.body.content,
      });

      const comment = await storage.addComment(validatedData);

      // Handle file attachments
      if (req.files && req.files.length > 0) {
        for (const file of req.files) {
          await storage.addAttachment({
            commentId: comment.id,
            filename: file.filename,
            originalName: file.originalname,
            mimeType: file.mimetype,
            size: file.size,
            uploadedById: userId,
          });
        }
      }

      // Send notification email
      const ticketDetails = await storage.getTicket(req.params.id);
      if (ticketDetails) {
        try {
          await sendNotificationEmail("comment_added", {
            ticketId: ticketDetails.id,
            subject: ticketDetails.subject,
            commentAuthor: req.user.claims.email || "Unknown User",
            recipientEmail: ticketDetails.createdBy.email,
          });
        } catch (emailError) {
          console.error("Failed to send notification email:", emailError);
        }
      }

      res.json(comment);
    } catch (error) {
      console.error("Error adding comment:", error);
      res.status(500).json({ message: "Failed to add comment" });
    }
  });

  // Voting
  app.post('/api/tickets/:id/vote', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { voteType } = req.body;

      if (!["up", "down"].includes(voteType)) {
        return res.status(400).json({ message: "Invalid vote type" });
      }

      const validatedData = insertTicketVoteSchema.parse({
        ticketId: req.params.id,
        userId,
        voteType,
      });

      await storage.voteTicket(validatedData);
      res.json({ success: true });
    } catch (error) {
      console.error("Error voting on ticket:", error);
      res.status(500).json({ message: "Failed to vote on ticket" });
    }
  });

  // File downloads
  app.get('/api/attachments/:id/download', isAuthenticated, async (req, res) => {
    try {
      const attachment = await storage.getAttachment(req.params.id);
      
      if (!attachment) {
        return res.status(404).json({ message: "Attachment not found" });
      }

      const filePath = path.join(uploadDir, attachment.filename);
      
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "File not found" });
      }

      res.setHeader('Content-Disposition', `attachment; filename="${attachment.originalName}"`);
      res.setHeader('Content-Type', attachment.mimeType);
      res.sendFile(filePath);
    } catch (error) {
      console.error("Error downloading attachment:", error);
      res.status(500).json({ message: "Failed to download attachment" });
    }
  });

  // User management (admin only)
  app.put('/api/users/:id/role', isAuthenticated, async (req: any, res) => {
    try {
      const currentUserId = req.user.claims.sub;
      const currentUser = await storage.getUser(currentUserId);
      
      if (currentUser?.role !== "admin") {
        return res.status(403).json({ message: "Only admins can update user roles" });
      }

      const { role } = req.body;
      if (!["user", "agent", "admin"].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }

      const user = await storage.updateUserRole(req.params.id, role);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json(user);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
