import nodemailer from "nodemailer";

interface EmailNotificationData {
  ticketId: string;
  subject: string;
  createdBy?: string;
  status?: string;
  commentAuthor?: string;
  recipientEmail?: string;
}

// Configure email transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || "smtp.gmail.com",
  port: parseInt(process.env.SMTP_PORT || "587"),
  secure: false,
  auth: {
    user: process.env.SMTP_USER || process.env.EMAIL_USER,
    pass: process.env.SMTP_PASS || process.env.EMAIL_PASS,
  },
});

export async function sendNotificationEmail(
  type: "ticket_created" | "status_updated" | "comment_added",
  data: EmailNotificationData
) {
  if (!process.env.SMTP_USER && !process.env.EMAIL_USER) {
    console.log("Email notifications disabled - no SMTP configuration found");
    return;
  }

  let subject: string;
  let htmlContent: string;
  let recipients: string[] = [];

  switch (type) {
    case "ticket_created":
      subject = `New Ticket Created: ${data.subject}`;
      htmlContent = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background-color: #1976d2; color: white; padding: 20px; text-align: center;">
            <h1 style="margin: 0;">QuickDesk - New Ticket</h1>
          </div>
          <div style="padding: 20px; background-color: #f5f5f5;">
            <h2>New support ticket has been created</h2>
            <p><strong>Ticket ID:</strong> #${data.ticketId}</p>
            <p><strong>Subject:</strong> ${data.subject}</p>
            <p><strong>Created by:</strong> ${data.createdBy}</p>
            <div style="margin-top: 20px;">
              <a href="${process.env.REPLIT_DOMAINS?.split(',')[0] || 'http://localhost:5000'}/tickets/${data.ticketId}" 
                 style="background-color: #1976d2; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;">
                View Ticket
              </a>
            </div>
          </div>
        </div>
      `;
      // Send to all agents and admins
      recipients = ["support@quickdesk.com"]; // This would be dynamically fetched from database
      break;

    case "status_updated":
      subject = `Ticket Status Updated: ${data.subject}`;
      htmlContent = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background-color: #1976d2; color: white; padding: 20px; text-align: center;">
            <h1 style="margin: 0;">QuickDesk - Ticket Update</h1>
          </div>
          <div style="padding: 20px; background-color: #f5f5f5;">
            <h2>Your ticket status has been updated</h2>
            <p><strong>Ticket ID:</strong> #${data.ticketId}</p>
            <p><strong>Subject:</strong> ${data.subject}</p>
            <p><strong>New Status:</strong> ${data.status?.replace('_', ' ').toUpperCase()}</p>
            <div style="margin-top: 20px;">
              <a href="${process.env.REPLIT_DOMAINS?.split(',')[0] || 'http://localhost:5000'}/tickets/${data.ticketId}" 
                 style="background-color: #1976d2; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;">
                View Ticket
              </a>
            </div>
          </div>
        </div>
      `;
      if (data.recipientEmail) {
        recipients = [data.recipientEmail];
      }
      break;

    case "comment_added":
      subject = `New Comment on Ticket: ${data.subject}`;
      htmlContent = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background-color: #1976d2; color: white; padding: 20px; text-align: center;">
            <h1 style="margin: 0;">QuickDesk - New Comment</h1>
          </div>
          <div style="padding: 20px; background-color: #f5f5f5;">
            <h2>A new comment has been added to your ticket</h2>
            <p><strong>Ticket ID:</strong> #${data.ticketId}</p>
            <p><strong>Subject:</strong> ${data.subject}</p>
            <p><strong>Comment by:</strong> ${data.commentAuthor}</p>
            <div style="margin-top: 20px;">
              <a href="${process.env.REPLIT_DOMAINS?.split(',')[0] || 'http://localhost:5000'}/tickets/${data.ticketId}" 
                 style="background-color: #1976d2; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;">
                View Comment
              </a>
            </div>
          </div>
        </div>
      `;
      if (data.recipientEmail) {
        recipients = [data.recipientEmail];
      }
      break;
  }

  if (recipients.length === 0) {
    console.log("No recipients for email notification");
    return;
  }

  try {
    await transporter.sendMail({
      from: `"QuickDesk Support" <${process.env.SMTP_USER || process.env.EMAIL_USER}>`,
      to: recipients.join(", "),
      subject,
      html: htmlContent,
    });

    console.log(`Email notification sent: ${type} for ticket ${data.ticketId}`);
  } catch (error) {
    console.error("Failed to send email notification:", error);
    throw error;
  }
}
