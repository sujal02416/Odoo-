# QuickDesk Help Desk System

## Overview

QuickDesk is a comprehensive help desk system built with a modern full-stack architecture. The application enables users to submit support tickets, allows support agents to manage and resolve issues, and provides administrators with oversight capabilities. The system features role-based access control, real-time notifications, file attachments, and a responsive web interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent, accessible design
- **Styling**: Tailwind CSS with CSS variables for theming and responsive design
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js for RESTful API endpoints
- **Language**: TypeScript for type safety across the entire stack
- **Database ORM**: Drizzle ORM with PostgreSQL for type-safe database operations
- **Authentication**: OpenID Connect integration with Replit authentication
- **Session Management**: Express sessions with PostgreSQL storage
- **File Uploads**: Multer middleware for handling ticket attachments

### Database Design
- **Primary Database**: PostgreSQL with connection pooling via Neon Database
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Core Tables**:
  - Users with role-based permissions (user, agent, admin)
  - Categories for ticket organization
  - Tickets with status tracking and priority levels
  - Comments for ticket communication
  - Attachments for file storage
  - Ticket votes for priority ranking
  - Sessions for authentication state

### Authentication & Authorization
- **Provider**: Replit OpenID Connect for seamless authentication
- **Session Storage**: PostgreSQL-based session store with automatic cleanup
- **Role-Based Access**: Three-tier permission system (end users, support agents, administrators)
- **Security**: HTTP-only cookies with secure flags for production environments

### File Management
- **Upload Handling**: Local file system storage with configurable limits (10MB default)
- **File Types**: Support for images (JPEG, PNG, GIF), PDFs, and text files
- **Security**: MIME type validation and file size restrictions

### Email Notifications
- **Service**: Nodemailer with configurable SMTP settings
- **Triggers**: Automated emails for ticket creation, status updates, and new comments
- **Templates**: HTML email templates with branded styling
- **Configuration**: Environment-based email credentials for flexible deployment

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Connection Management**: WebSocket-based connections for improved performance

### Authentication Services
- **Replit OpenID**: Integrated authentication provider for user management
- **Session Storage**: PostgreSQL-backed session persistence

### Email Services
- **SMTP Provider**: Configurable email service (Gmail SMTP by default)
- **Email Templates**: Custom HTML templates for notification emails

### Development Tools
- **Replit Integration**: Native support for Replit development environment
- **Error Tracking**: Runtime error overlay for development debugging
- **Hot Reload**: Vite HMR for rapid development cycles

### UI/UX Libraries
- **Radix UI**: Headless component primitives for accessibility
- **Lucide Icons**: Consistent icon library for UI elements
- **Date Formatting**: date-fns for human-readable timestamps
- **Form Handling**: React Hook Form with Zod validation

### Build & Development
- **TypeScript**: Full-stack type safety with strict configuration
- **ESBuild**: Fast bundling for production server builds
- **PostCSS**: CSS processing with Tailwind CSS integration
- **Path Aliasing**: Simplified imports with @ aliases for client code