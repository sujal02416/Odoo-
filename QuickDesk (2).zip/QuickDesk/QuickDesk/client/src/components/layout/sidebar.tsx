import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Ticket, 
  Users, 
  Plus, 
  BarChart3, 
  Settings, 
  Tags,
  LogOut,
  Headset
} from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const navigationItems = [
    { path: "/", icon: LayoutDashboard, label: "Dashboard" },
    { path: "/tickets", icon: Ticket, label: "All Tickets", badge: null },
    { path: "/tickets?assignedToId=me", icon: Users, label: "My Tickets", badge: null },
    { path: "/create-ticket", icon: Plus, label: "Create Ticket" },
    { path: "/reports", icon: BarChart3, label: "Reports" },
  ];

  const adminItems = [
    { path: "/users", icon: Users, label: "Manage Users" },
    { path: "/categories", icon: Tags, label: "Categories" },
  ];

  const NavItem = ({ item, isActive }: { item: any; isActive: boolean }) => (
    <a
      href={item.path}
      className={cn(
        "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors",
        isActive
          ? "bg-primary/10 text-primary font-medium"
          : "text-gray-600 hover:bg-gray-100"
      )}
    >
      <item.icon className="w-5 h-5" />
      <span>{item.label}</span>
      {item.badge && (
        <span className="ml-auto bg-gray-200 text-gray-700 text-xs px-2 py-1 rounded-full">
          {item.badge}
        </span>
      )}
    </a>
  );

  return (
    <aside className="w-64 bg-white shadow-lg z-10 flex flex-col">
      {/* Logo Section */}
      <div className="flex items-center px-6 py-4 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Headset className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="text-xl font-semibold text-gray-900">QuickDesk</span>
        </div>
      </div>

      {/* User Profile Section */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <img 
            src={user?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"} 
            alt="User profile" 
            className="w-10 h-10 rounded-full object-cover"
          />
          <div>
            <p className="text-sm font-medium text-gray-900">
              {user?.firstName || user?.lastName 
                ? `${user.firstName || ""} ${user.lastName || ""}`.trim()
                : user?.email?.split("@")[0] || "User"
              }
            </p>
            <p className="text-xs text-gray-500 capitalize">
              {user?.role === "user" ? "End User" : user?.role?.replace("_", " ") || "User"}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 px-4 py-4 space-y-2">
        {navigationItems.map((item) => (
          <NavItem
            key={item.path}
            item={item}
            isActive={location === item.path || (item.path === "/" && location === "")}
          />
        ))}
        
        {/* Admin Section */}
        {user?.role === "admin" && (
          <div className="pt-4 border-t border-gray-200 mt-4">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-3 mb-2">
              Administration
            </p>
            {adminItems.map((item) => (
              <NavItem
                key={item.path}
                item={item}
                isActive={location === item.path}
              />
            ))}
          </div>
        )}
      </nav>

      {/* Logout */}
      <div className="px-4 py-4 border-t border-gray-200">
        <button 
          className="flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-100 transition-colors w-full"
          onClick={() => window.location.href = "/api/logout"}
        >
          <LogOut className="w-5 h-5" />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );
}
