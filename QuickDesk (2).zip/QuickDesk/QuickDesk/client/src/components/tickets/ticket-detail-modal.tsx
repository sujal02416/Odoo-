import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { Paperclip, Download, MessageCircle } from "lucide-react";

interface TicketDetailModalProps {
  ticketId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function TicketDetailModal({ ticketId, open, onOpenChange }: TicketDetailModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newComment, setNewComment] = useState("");

  const { data: ticket, isLoading } = useQuery({
    queryKey: ["/api/tickets", ticketId],
    enabled: open && !!ticketId,
  });

  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      const response = await apiRequest("PUT", `/api/tickets/${ticketId}/status`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tickets", ticketId] });
      toast({ title: "Success", description: "Ticket status updated" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update status", variant: "destructive" });
    },
  });

  const assignMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("PUT", `/api/tickets/${ticketId}/assign`, { assignedToId: user?.id });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tickets", ticketId] });
      toast({ title: "Success", description: "Ticket assigned to you" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to assign ticket", variant: "destructive" });
    },
  });

  const addCommentMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", `/api/tickets/${ticketId}/comments`, { content });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets", ticketId] });
      setNewComment("");
      toast({ title: "Success", description: "Comment added" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add comment", variant: "destructive" });
    },
  });

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "open": return "destructive";
      case "in_progress": return "default";
      case "resolved": return "secondary";
      case "closed": return "outline";
      default: return "default";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent": return "text-red-600";
      case "high": return "text-orange-600";
      case "medium": return "text-yellow-600";
      case "low": return "text-green-600";
      default: return "text-gray-600";
    }
  };

  if (isLoading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <div className="p-6">
            <div className="animate-pulse space-y-4">
              <div className="h-6 bg-gray-200 rounded w-1/2"></div>
              <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              <div className="h-32 bg-gray-200 rounded"></div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!ticket) {
    return null;
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center space-x-3">
            <DialogTitle>{ticket.subject}</DialogTitle>
            <Badge variant={getStatusVariant(ticket.status)}>
              {ticket.status?.replace('_', ' ').toUpperCase()}
            </Badge>
            {ticket.category && (
              <Badge variant="outline">{ticket.category.name}</Badge>
            )}
          </div>
          <p className="text-sm text-gray-500">
            Ticket #{ticket.id.slice(-8).toUpperCase()} • Created {formatDistanceToNow(new Date(ticket.createdAt), { addSuffix: true })}
          </p>
        </DialogHeader>
        
        <div className="flex">
          {/* Main Content */}
          <div className="flex-1 pr-6">
            <div className="space-y-6">
              {/* Original Request */}
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center space-x-3 mb-3">
                  <img 
                    src={ticket.createdBy?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"} 
                    alt="Ticket creator" 
                    className="w-8 h-8 rounded-full object-cover"
                  />
                  <div>
                    <p className="text-sm font-medium text-gray-900">
                      {ticket.createdBy?.firstName || ticket.createdBy?.email?.split('@')[0] || 'Unknown'}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatDistanceToNow(new Date(ticket.createdAt), { addSuffix: true })}
                    </p>
                  </div>
                </div>
                <p className="text-sm text-gray-700">{ticket.description}</p>
              </div>

              {/* Comments Thread */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">Comments</h3>
                
                {ticket.comments?.map((comment: any) => (
                  <div key={comment.id} className="border-l-4 border-primary/20 pl-4">
                    <div className="flex items-center space-x-3 mb-2">
                      <img 
                        src={comment.author?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"} 
                        alt="Comment author" 
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {comment.author?.firstName || comment.author?.email?.split('@')[0] || 'Unknown'}
                        </p>
                        <p className="text-xs text-gray-500">
                          {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                        </p>
                      </div>
                      {comment.author?.role === "agent" && (
                        <Badge variant="secondary" className="text-xs">Agent</Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-700">{comment.content}</p>
                    {comment.attachments?.length > 0 && (
                      <div className="mt-2 space-y-1">
                        {comment.attachments.map((attachment: any) => (
                          <div key={attachment.id} className="flex items-center space-x-2 text-xs text-gray-500">
                            <Paperclip className="w-3 h-3" />
                            <span>{attachment.originalName}</span>
                            <Button variant="ghost" size="sm" className="h-auto p-0">
                              <Download className="w-3 h-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Add Comment Form */}
              {(user?.role === "agent" || user?.role === "admin" || user?.id === ticket.createdById) && (
                <div className="border-t border-gray-200 pt-6">
                  <div className="space-y-4">
                    <Textarea
                      placeholder="Type your response here..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      rows={4}
                      className="resize-none"
                    />
                    <div className="flex items-center justify-between">
                      <Button variant="ghost" size="sm">
                        <Paperclip className="w-4 h-4 mr-1" />
                        Attach File
                      </Button>
                      <Button 
                        onClick={() => addCommentMutation.mutate(newComment)}
                        disabled={!newComment.trim() || addCommentMutation.isPending}
                      >
                        {addCommentMutation.isPending ? "Adding..." : "Add Comment"}
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Actions Sidebar */}
          <div className="w-80 border-l border-gray-200 pl-6 bg-gray-50 rounded-lg p-4 space-y-6">
            {/* Ticket Actions */}
            {(user?.role === "agent" || user?.role === "admin") && (
              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-3">Actions</h3>
                <div className="space-y-2">
                  <Select 
                    value={ticket.status}
                    onValueChange={(value) => updateStatusMutation.mutate(value)}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                  {!ticket.assignedTo && (
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => assignMutation.mutate()}
                      disabled={assignMutation.isPending}
                    >
                      {assignMutation.isPending ? "Assigning..." : "Assign to Me"}
                    </Button>
                  )}
                </div>
              </div>
            )}

            {/* Ticket Details */}
            <div>
              <h3 className="text-sm font-semibold text-gray-900 mb-3">Details</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Priority:</span>
                  <span className={`font-medium ${getPriorityColor(ticket.priority)}`}>
                    {ticket.priority?.toUpperCase()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Assigned to:</span>
                  <span className="font-medium text-gray-900">
                    {ticket.assignedTo?.firstName || ticket.assignedTo?.email?.split('@')[0] || "Unassigned"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Created:</span>
                  <span className="font-medium text-gray-900">
                    {new Date(ticket.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Last updated:</span>
                  <span className="font-medium text-gray-900">
                    {formatDistanceToNow(new Date(ticket.updatedAt), { addSuffix: true })}
                  </span>
                </div>
              </div>
            </div>

            {/* Attachments */}
            {ticket.attachments?.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-3">Attachments</h3>
                <div className="space-y-2">
                  {ticket.attachments.map((attachment: any) => (
                    <div key={attachment.id} className="flex items-center space-x-3 p-2 bg-white rounded-lg border border-gray-200">
                      <div className="w-8 h-8 bg-red-100 rounded flex items-center justify-center">
                        <Paperclip className="w-4 h-4 text-red-500" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {attachment.originalName}
                        </p>
                        <p className="text-xs text-gray-500">
                          {Math.round(attachment.size / 1024)} KB
                        </p>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
