import { Badge } from "@/components/ui/badge";
import { MessageCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface TicketCardProps {
  ticket: any;
  onClick?: () => void;
}

export default function TicketCard({ ticket, onClick }: TicketCardProps) {
  const getStatusVariant = (status: string) => {
    switch (status) {
      case "open": return "destructive";
      case "in_progress": return "default";
      case "resolved": return "secondary";
      case "closed": return "outline";
      default: return "default";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent": return "text-red-600";
      case "high": return "text-orange-600";
      case "medium": return "text-yellow-600";
      case "low": return "text-green-600";
      default: return "text-gray-600";
    }
  };

  return (
    <div
      className="px-6 py-4 hover:bg-gray-50 transition-colors cursor-pointer"
      onClick={onClick}
    >
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-3 mb-1">
            <span className="text-sm font-medium text-gray-900">
              #{ticket.id.slice(-8).toUpperCase()}
            </span>
            <Badge variant={getStatusVariant(ticket.status)}>
              {ticket.status?.replace('_', ' ').toUpperCase() || 'UNKNOWN'}
            </Badge>
            {ticket.category && (
              <Badge variant="outline">
                {ticket.category.name}
              </Badge>
            )}
            <span className={`text-xs font-medium ${getPriorityColor(ticket.priority)}`}>
              {ticket.priority?.toUpperCase()}
            </span>
          </div>
          <h4 className="text-sm font-medium text-gray-900 mb-1">
            {ticket.subject}
          </h4>
          <p className="text-sm text-gray-500">
            Created by {ticket.createdBy?.firstName || ticket.createdBy?.email?.split('@')[0] || 'Unknown'} • {' '}
            {formatDistanceToNow(new Date(ticket.createdAt), { addSuffix: true })}
          </p>
        </div>
        <div className="flex items-center space-x-3">
          {ticket.commentCount > 0 && (
            <div className="flex items-center text-sm text-gray-500">
              <MessageCircle className="w-4 h-4 mr-1" />
              <span>{ticket.commentCount}</span>
            </div>
          )}
          {ticket.assignedTo && (
            <img
              src={ticket.assignedTo.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150"}
              alt="Assigned agent"
              className="w-8 h-8 rounded-full object-cover"
            />
          )}
        </div>
      </div>
    </div>
  );
}
