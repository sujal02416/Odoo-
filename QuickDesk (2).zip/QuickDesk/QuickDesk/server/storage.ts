import {
  users,
  categories,
  tickets,
  comments,
  attachments,
  ticketVotes,
  type User,
  type UpsertUser,
  type Category,
  type InsertCategory,
  type Ticket,
  type InsertTicket,
  type TicketWithDetails,
  type Comment,
  type InsertComment,
  type Attachment,
  type InsertAttachment,
  type TicketVote,
  type InsertTicketVote,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and, or, ilike, sql, count } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserRole(id: string, role: string): Promise<User | undefined>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: string, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: string): Promise<boolean>;
  
  // Ticket operations
  getTickets(filters?: {
    status?: string;
    categoryId?: string;
    assignedToId?: string;
    createdById?: string;
    search?: string;
    sortBy?: "created" | "updated" | "priority" | "replies";
    sortOrder?: "asc" | "desc";
    limit?: number;
    offset?: number;
  }): Promise<{ tickets: TicketWithDetails[]; total: number }>;
  getTicket(id: string, userId?: string): Promise<TicketWithDetails | undefined>;
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  updateTicket(id: string, updates: Partial<InsertTicket>): Promise<Ticket | undefined>;
  assignTicket(id: string, assignedToId: string): Promise<Ticket | undefined>;
  
  // Comment operations
  addComment(comment: InsertComment): Promise<Comment>;
  getTicketComments(ticketId: string): Promise<(Comment & { author: User; attachments: Attachment[] })[]>;
  
  // Attachment operations
  addAttachment(attachment: InsertAttachment): Promise<Attachment>;
  getAttachment(id: string): Promise<Attachment | undefined>;
  deleteAttachment(id: string): Promise<boolean>;
  
  // Vote operations
  voteTicket(vote: InsertTicketVote): Promise<void>;
  getUserTicketVote(ticketId: string, userId: string): Promise<TicketVote | undefined>;
  
  // Dashboard stats
  getDashboardStats(userId?: string, role?: string): Promise<{
    openTickets: number;
    inProgressTickets: number;
    resolvedToday: number;
    avgResponseTime: string;
    categoryDistribution: { categoryId: string; categoryName: string; count: number }[];
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserRole(id: string, role: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ role, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(asc(categories.name));
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  async updateCategory(id: string, categoryData: Partial<InsertCategory>): Promise<Category | undefined> {
    const [category] = await db
      .update(categories)
      .set(categoryData)
      .where(eq(categories.id, id))
      .returning();
    return category;
  }

  async deleteCategory(id: string): Promise<boolean> {
    const result = await db.delete(categories).where(eq(categories.id, id));
    return result.rowCount > 0;
  }

  async getTickets(filters?: {
    status?: string;
    categoryId?: string;
    assignedToId?: string;
    createdById?: string;
    search?: string;
    sortBy?: "created" | "updated" | "priority" | "replies";
    sortOrder?: "asc" | "desc";
    limit?: number;
    offset?: number;
  }): Promise<{ tickets: TicketWithDetails[]; total: number }> {
    let query = db
      .select({
        ticket: tickets,
        category: categories,
        createdBy: users,
        assignedTo: {
          id: sql`assigned_user.id`,
          email: sql`assigned_user.email`,
          firstName: sql`assigned_user.first_name`,
          lastName: sql`assigned_user.last_name`,
          profileImageUrl: sql`assigned_user.profile_image_url`,
          role: sql`assigned_user.role`,
          createdAt: sql`assigned_user.created_at`,
          updatedAt: sql`assigned_user.updated_at`,
        },
        commentCount: sql<number>`COALESCE(comment_counts.count, 0)`,
      })
      .from(tickets)
      .leftJoin(categories, eq(tickets.categoryId, categories.id))
      .leftJoin(users, eq(tickets.createdById, users.id))
      .leftJoin(sql`users as assigned_user`, sql`tickets.assigned_to_id = assigned_user.id`)
      .leftJoin(
        sql`(SELECT ticket_id, COUNT(*) as count FROM comments GROUP BY ticket_id) as comment_counts`,
        sql`tickets.id = comment_counts.ticket_id`
      );

    const conditions = [];

    if (filters?.status) {
      conditions.push(eq(tickets.status, filters.status as any));
    }
    if (filters?.categoryId) {
      conditions.push(eq(tickets.categoryId, filters.categoryId));
    }
    if (filters?.assignedToId) {
      conditions.push(eq(tickets.assignedToId, filters.assignedToId));
    }
    if (filters?.createdById) {
      conditions.push(eq(tickets.createdById, filters.createdById));
    }
    if (filters?.search) {
      conditions.push(
        or(
          ilike(tickets.subject, `%${filters.search}%`),
          ilike(tickets.description, `%${filters.search}%`)
        )
      );
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    // Sorting
    let orderBy;
    const isDesc = filters?.sortOrder === "desc";
    switch (filters?.sortBy) {
      case "updated":
        orderBy = isDesc ? desc(tickets.updatedAt) : asc(tickets.updatedAt);
        break;
      case "priority":
        orderBy = isDesc ? desc(tickets.priority) : asc(tickets.priority);
        break;
      case "replies":
        orderBy = isDesc ? sql`comment_counts.count DESC NULLS LAST` : sql`comment_counts.count ASC NULLS LAST`;
        break;
      default:
        orderBy = isDesc ? desc(tickets.createdAt) : asc(tickets.createdAt);
    }

    query = query.orderBy(orderBy);

    // Get total count
    let countQuery = db.select({ count: count() }).from(tickets);
    if (conditions.length > 0) {
      countQuery = countQuery.where(and(...conditions));
    }
    const [{ count: total }] = await countQuery;

    // Apply pagination
    if (filters?.limit) {
      query = query.limit(filters.limit);
    }
    if (filters?.offset) {
      query = query.offset(filters.offset);
    }

    const results = await query;

    // Transform results and fetch additional data
    const ticketsWithDetails: TicketWithDetails[] = await Promise.all(
      results.map(async (row) => {
        const ticketComments = await this.getTicketComments(row.ticket.id);
        const ticketAttachments = await db
          .select()
          .from(attachments)
          .where(eq(attachments.ticketId, row.ticket.id));

        return {
          ...row.ticket,
          category: row.category || undefined,
          createdBy: row.createdBy,
          assignedTo: row.assignedTo.id ? (row.assignedTo as User) : undefined,
          comments: ticketComments,
          attachments: ticketAttachments,
          commentCount: row.commentCount,
        };
      })
    );

    return { tickets: ticketsWithDetails, total };
  }

  async getTicket(id: string, userId?: string): Promise<TicketWithDetails | undefined> {
    const [ticketRow] = await db
      .select({
        ticket: tickets,
        category: categories,
        createdBy: users,
        assignedTo: {
          id: sql`assigned_user.id`,
          email: sql`assigned_user.email`,
          firstName: sql`assigned_user.first_name`,
          lastName: sql`assigned_user.last_name`,
          profileImageUrl: sql`assigned_user.profile_image_url`,
          role: sql`assigned_user.role`,
          createdAt: sql`assigned_user.created_at`,
          updatedAt: sql`assigned_user.updated_at`,
        },
      })
      .from(tickets)
      .leftJoin(categories, eq(tickets.categoryId, categories.id))
      .leftJoin(users, eq(tickets.createdById, users.id))
      .leftJoin(sql`users as assigned_user`, sql`tickets.assigned_to_id = assigned_user.id`)
      .where(eq(tickets.id, id));

    if (!ticketRow) return undefined;

    const ticketComments = await this.getTicketComments(id);
    const ticketAttachments = await db
      .select()
      .from(attachments)
      .where(eq(attachments.ticketId, id));

    let userVote: "up" | "down" | null = null;
    if (userId) {
      const vote = await this.getUserTicketVote(id, userId);
      userVote = vote ? (vote.voteType as "up" | "down") : null;
    }

    return {
      ...ticketRow.ticket,
      category: ticketRow.category || undefined,
      createdBy: ticketRow.createdBy,
      assignedTo: ticketRow.assignedTo.id ? (ticketRow.assignedTo as User) : undefined,
      comments: ticketComments,
      attachments: ticketAttachments,
      commentCount: ticketComments.length,
      userVote,
    };
  }

  async createTicket(ticket: InsertTicket): Promise<Ticket> {
    const [newTicket] = await db.insert(tickets).values(ticket).returning();
    return newTicket;
  }

  async updateTicket(id: string, updates: Partial<InsertTicket>): Promise<Ticket | undefined> {
    const [ticket] = await db
      .update(tickets)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(tickets.id, id))
      .returning();
    return ticket;
  }

  async assignTicket(id: string, assignedToId: string): Promise<Ticket | undefined> {
    const [ticket] = await db
      .update(tickets)
      .set({ assignedToId, updatedAt: new Date() })
      .where(eq(tickets.id, id))
      .returning();
    return ticket;
  }

  async addComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db.insert(comments).values(comment).returning();
    
    // Update ticket's updatedAt timestamp
    await db
      .update(tickets)
      .set({ updatedAt: new Date() })
      .where(eq(tickets.id, comment.ticketId));
    
    return newComment;
  }

  async getTicketComments(ticketId: string): Promise<(Comment & { author: User; attachments: Attachment[] })[]> {
    const commentResults = await db
      .select({
        comment: comments,
        author: users,
      })
      .from(comments)
      .leftJoin(users, eq(comments.authorId, users.id))
      .where(eq(comments.ticketId, ticketId))
      .orderBy(asc(comments.createdAt));

    const commentsWithAttachments = await Promise.all(
      commentResults.map(async (row) => {
        const commentAttachments = await db
          .select()
          .from(attachments)
          .where(eq(attachments.commentId, row.comment.id));

        return {
          ...row.comment,
          author: row.author,
          attachments: commentAttachments,
        };
      })
    );

    return commentsWithAttachments;
  }

  async addAttachment(attachment: InsertAttachment): Promise<Attachment> {
    const [newAttachment] = await db.insert(attachments).values(attachment).returning();
    return newAttachment;
  }

  async getAttachment(id: string): Promise<Attachment | undefined> {
    const [attachment] = await db.select().from(attachments).where(eq(attachments.id, id));
    return attachment;
  }

  async deleteAttachment(id: string): Promise<boolean> {
    const result = await db.delete(attachments).where(eq(attachments.id, id));
    return result.rowCount > 0;
  }

  async voteTicket(vote: InsertTicketVote): Promise<void> {
    // First, remove any existing vote by this user for this ticket
    await db
      .delete(ticketVotes)
      .where(and(eq(ticketVotes.ticketId, vote.ticketId), eq(ticketVotes.userId, vote.userId)));

    // Insert the new vote
    await db.insert(ticketVotes).values(vote);

    // Update the ticket's vote counts
    const upCount = await db
      .select({ count: count() })
      .from(ticketVotes)
      .where(and(eq(ticketVotes.ticketId, vote.ticketId), eq(ticketVotes.voteType, "up")));

    const downCount = await db
      .select({ count: count() })
      .from(ticketVotes)
      .where(and(eq(ticketVotes.ticketId, vote.ticketId), eq(ticketVotes.voteType, "down")));

    await db
      .update(tickets)
      .set({
        upvotes: upCount[0].count,
        downvotes: downCount[0].count,
        updatedAt: new Date(),
      })
      .where(eq(tickets.id, vote.ticketId));
  }

  async getUserTicketVote(ticketId: string, userId: string): Promise<TicketVote | undefined> {
    const [vote] = await db
      .select()
      .from(ticketVotes)
      .where(and(eq(ticketVotes.ticketId, ticketId), eq(ticketVotes.userId, userId)));
    return vote;
  }

  async getDashboardStats(userId?: string, role?: string): Promise<{
    openTickets: number;
    inProgressTickets: number;
    resolvedToday: number;
    avgResponseTime: string;
    categoryDistribution: { categoryId: string; categoryName: string; count: number }[];
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let openQuery = db.select({ count: count() }).from(tickets).where(eq(tickets.status, "open"));
    let inProgressQuery = db.select({ count: count() }).from(tickets).where(eq(tickets.status, "in_progress"));

    // If user is an agent, only count their assigned tickets
    if (role === "agent" && userId) {
      openQuery = openQuery.where(eq(tickets.assignedToId, userId));
      inProgressQuery = inProgressQuery.where(eq(tickets.assignedToId, userId));
    }

    const [openCount] = await openQuery;
    const [inProgressCount] = await inProgressQuery;

    const [resolvedTodayCount] = await db
      .select({ count: count() })
      .from(tickets)
      .where(and(eq(tickets.status, "resolved"), sql`${tickets.updatedAt} >= ${today}`));

    // Calculate average response time (simplified)
    const avgResponseTime = "2.4h"; // This would need more complex calculation

    // Category distribution
    const categoryStats = await db
      .select({
        categoryId: categories.id,
        categoryName: categories.name,
        count: count(tickets.id),
      })
      .from(categories)
      .leftJoin(tickets, eq(categories.id, tickets.categoryId))
      .groupBy(categories.id, categories.name)
      .orderBy(desc(count(tickets.id)));

    return {
      openTickets: openCount.count,
      inProgressTickets: inProgressCount.count,
      resolvedToday: resolvedTodayCount.count,
      avgResponseTime,
      categoryDistribution: categoryStats,
    };
  }
}

export const storage = new DatabaseStorage();
